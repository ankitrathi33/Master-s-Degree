if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("Biostrings")

install.packages('seqinr')
BiocManager::install('msa')
install.packages('ape')
BiocManager::install("DECIPHER")
library(DECIPHER)

library(Biostrings)
library(seqinr)
library(msa)
library(ape)


setwd(paste(getwd(),'/Documents/Golu Projects/Lab_1/Data-20200402/Pairwise_Alignment',sep=''))

bat_nucleocapsid=read.fasta("BAT_nucleocapsid.fasta" )
bat_orf1ab=read.fasta("BAT_ORF1ab.fasta" )
bat_orf8=read.fasta("BAT_ORF8.fasta" )
human_nucleocapsid=read.fasta("HUMAN_nucleocapsid.fasta" )
human_orf1ab=read.fasta("HUMAN_ORF1ab.fasta" )
human_orf8=read.fasta("HUMAN_ORF8.fasta" )





length(bat_nucleocapsid$ATO98190.1) #422
length(bat_orf1ab$ATO98179.1) #7073
length(bat_orf8$ATO98189.1) #121

length(human_nucleocapsid$YP_009724397.2) #419
length(human_orf1ab$YP_009724389.1) #7096
length(human_orf8$YP_009724396.1) #121


#pairwise alignment for bat v human

#nucleotide
Seq1 = toupper(paste(bat_nucleocapsid$ATO98190.1, collapse=""))
Seq2 = toupper(paste(human_nucleocapsid$YP_009724397.2, collapse=""))

p_1<-pairwiseAlignment(Seq1,Seq2,
                  substitutionMatrix="BLOSUM62",
                  gapOpening=-8,
                  gapExtension=-2)
#pariwise alignment values
p_1
#identity
pid(p_1)

#orf1ab
Seq1 = toupper(paste(bat_orf1ab$ATO98179.1, collapse=""))
Seq2 = toupper(paste(human_orf1ab$YP_009724389.1, collapse=""))

p_1<-pairwiseAlignment(Seq1,Seq2,
                  substitutionMatrix="BLOSUM62",
                  gapOpening=-8,
                  gapExtension=-2)
#pariwise alignment values
p_1
#identity
pid(p_1)


#orf8
Seq1 = toupper(paste(bat_orf8$ATO98189.1, collapse=""))
Seq2 = toupper(paste(human_orf8$YP_009724396.1, collapse=""))

p_1<-pairwiseAlignment(Seq1,Seq2,
                  substitutionMatrix="BLOSUM62",
                  gapOpening=-8,
                  gapExtension=-2)
#pariwise alignment values
p_1
#identity
pid(p_1)

#dot plots
#nucleocapsid
dotPlot(bat_nucleocapsid$ATO98190.1,human_nucleocapsid$YP_009724397.2)

#bat_orf8
dotPlot(bat_orf8$ATO98189.1,human_orf8$YP_009724396.1)

#orf1ab
dotPlot(bat_orf1ab$ATO98179.1,human_orf1ab$YP_009724389.1)

#
setwd(sub('Pairwise_Alignment','Multiple_Alignment',getwd()))
analysed_protein<-read.fasta("M_protein.fasta")

#length of the proteins
lapply(analysed_protein,length)

#reading as string
analysed_protein<-readAAStringSet("M_protein.fasta")

msa_1<-msa(analysed_protein,
          method='ClustalW',
          gapOpening=-8,
          gapExtension=-2,
    substitutionMatrix='blosum')

names(msa_1)
  
#distince 

msa_convert<-msaConvert(msa_1)
matrix_distance<-as.matrix(dist.alignment(msa_convert))
View(matrix_distance)



#phylogenetic tree

nj_obj<-nj(matrix_distance)
plot.phylo(nj_obj)
title("phylogenetic tree")
axisPhylo()



