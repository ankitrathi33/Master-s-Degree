if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("DESeq2")
#To check if the package was installed successfully, please restart R and load the library:
library("DESeq2")
library(dplyr)
dir<-getwd()
setwd(paste(dir,'/Documents/Golu Projects/lab3',sep=''))
load('RNASeq_data.Rdata')


#4. How many samples are assigned to Rotavirus, and how many to
#Shigella? Hint: you can use the table() function in R.
table(coldata$organism)

#Rotavirus  Shigella 
#55        37 


#5 What are the classes of age of patients? How many patients are in both classes? 
table(coldata$age)


#6.Create the training and testing subsets from gene_counts based on
#the described above rule. Name them: mytrainset and mytestset.
#Assign the indices of chosen patients for the training set to a vector variable train. Hint: you can use the sample() function.


#splitting into train and test 80 20 and making sure that sampling is done correctly
#splitting it into roa and shig and then taking samples of 80,20 and then merging them together

coldata$row_number<-1:nrow(coldata)
rota_patients<-coldata%>%filter(organism=='Rotavirus')
shigella_patients<-coldata%>%filter(organism=='Shigella')

rota_train_sample<-base::sample(1:nrow(rota_patients),0.8*nrow(rota_patients))
rota_test_sample<-setdiff(1:nrow(rota_patients),rota_train_sample)
rota_patients$flag<-'train'
rota_patients[rota_test_sample,'flag']<-'test'

shig_train_sample<-base::sample(1:nrow(shigella_patients),0.8*nrow(shigella_patients))
shig_test_sample<-setdiff(1:nrow(shigella_patients),shig_train_sample)
shigella_patients$flag<-'train'
shigella_patients[shig_test_sample,'flag']<-'test'

coldata_1<-rota_patients%>%rbind(shigella_patients)

coldata_1<-coldata_1%>%dplyr::arrange(row_number)

#verifying sampling is done containing equal samples in train and test
coldata_1%>%filter(flag=='train')%>%select(organism)%>%table()%>%prop.table()
coldata_1%>%filter(flag=='test')%>%select(organism)%>%table()%>%prop.table()

coldata_1$flag%>%table()%>%prop.table()

train_df<-coldata_1%>%filter(flag=='train')
train_index<-train_df$row_number

test_df<-coldata_1%>%filter(flag=='test')
test_index<-test_df$row_number



library("DESeq2")

rownames(coldata) = coldata$run
all(rownames(coldata) == colnames(mytrainset))

gene_counts[1,]%>%View()


mytrainset<-gene_counts[,train_df$run]
mytestset<-gene_counts[,test_df$run]

dds <- DESeqDataSetFromMatrix(countData = mytrainset,
                              colData = coldata_1%>%filter(flag=='train'),
                              design = ~ organism)


dds <- DESeq(dds)
res <- results(dds)
#7. How many genes had False Discovery Rate < 0.05? Hint: look for the padj column.
res[res$padj<0.05,]%>%nrow()  #212


#8. Which gene had the highest log2FoldChange?
max_value=max(res$log2FoldChange)
max_value_index<-which(res$log2FoldChange==max_value)
gene_max<-rowdata[max_value_index,]
gene_max


#9. What are the names of the top 10 genes which had the smallest pvalue? Save these genes to a variable called chosen_genes.

smalles_10=sort(res$pvalue)[1:10]
smllest_10_gene_index<-which(res$pvalue %in% smalles_10)
smalles_10_genes<-rowdata[smllest_10_gene_index,]

smalles_10_genes$gene_id


#10. Rewrite mytrainset and mytestset by saving the counts for chosen_genes only. 

mytrainset<-gene_counts[smalles_10_genes$gene_id,train_df$run]
mytestset<-gene_counts[smalles_10_genes$gene_id,test_df$run]


#11.What results did you get?


TrainSet <- data.frame(Outcome=coldata[coldata_1$flag=='train','organism'],
                       t(mytrainset))


TestSet <- data.frame(t(mytestset))


glm.fit <- glm(Outcome ~ .,
               data = TrainSet,
               family = binomial)

glm.probs <- predict(glm.fit,
                     newdata = TestSet,
                     type = "response")

glm.pred <- ifelse(glm.probs > 0.5, "Shigella", "Rotavirus")

confusion_matrix<-table(glm.pred, coldata[coldata_1$flag=='test','organism'])

missclassification_rate<-(confusion_matrix[1,1]+confusion_matrix[2,2])/sum(confusion_matrix)
missclassification_rate

###Validation method


rota_patients<-coldata%>%filter(organism=='Rotavirus')
shigella_patients<-coldata%>%filter(organism=='Shigella')
#Initalizing data frames to save gene count of 10 runs and missclassification rate of 10 counts
gene_run<-data.frame()
missclassification_rate_df<-data.frame()
#for iteration in 1:10
for (iteration in 1:10){


#splitting into train and test 80 20 and making sure that sampling is done correctly
#splitting it into roa and shig and then taking samples of 80,20 and then merging them together

rota_train_sample<-base::sample(1:nrow(rota_patients),0.8*nrow(rota_patients))
rota_test_sample<-setdiff(1:nrow(rota_patients),rota_train_sample)
rota_patients$flag<-'train'
rota_patients[rota_test_sample,'flag']<-'test'
shig_train_sample<-base::sample(1:nrow(shigella_patients),0.8*nrow(shigella_patients))
shig_test_sample<-setdiff(1:nrow(shigella_patients),shig_train_sample)
shigella_patients$flag<-'train'
shigella_patients[shig_test_sample,'flag']<-'test'
coldata_1<-rota_patients%>%rbind(shigella_patients)
coldata_1<-coldata_1%>%dplyr::arrange(row_number)
train_df<-coldata_1%>%filter(flag=='train')
train_index<-train_df$row_number
test_df<-coldata_1%>%filter(flag=='test')
test_index<-test_df$row_number

#choosing train and test
mytrainset<-gene_counts[,train_df$run]
mytestset<-gene_counts[,test_df$run]

#running gene selection
dds <- DESeqDataSetFromMatrix(countData = mytrainset,
                              colData = coldata_1%>%filter(flag=='train'),
                              design = ~ organism)


dds <- DESeq(dds)
res <- results(dds)


smalles_10=sort(res$pvalue)[1:10]
smllest_10_gene_index<-which(res$pvalue %in% smalles_10)
smalles_10_genes<-rowdata[smllest_10_gene_index,]

gene_run_1<-data.frame(genes=smalles_10_genes$gene_id)
gene_run_1$iteration_flag<-iteration
gene_run<-rbind(gene_run,gene_run_1)


mytrainset<-gene_counts[smalles_10_genes$gene_id,train_df$run]
mytestset<-gene_counts[smalles_10_genes$gene_id,test_df$run]

TrainSet <- data.frame(Outcome=coldata[coldata_1$flag=='train','organism'],
                       t(mytrainset))


TestSet <- data.frame(t(mytestset))

#running the model
glm.fit <- glm(Outcome ~ .,
               data = TrainSet,
               family = binomial)

glm.probs <- predict(glm.fit,
                     newdata = TestSet,
                     type = "response")

glm.pred <- ifelse(glm.probs > 0.5, "Shigella", "Rotavirus")

confusion_matrix<-table(glm.pred, coldata[coldata_1$flag=='test','organism'])


#missclassificatoin rate and binding
missclassification_rate<-(confusion_matrix[1,1]+confusion_matrix[2,2])/sum(confusion_matrix)
missclassification_rate_df_temp<-data.frame(missclassification_rate=missclassification_rate)
missclassification_rate_df_temp$iteration_flag<-iteration
missclassification_rate_df<-rbind(missclassification_rate_df,missclassification_rate_df_temp)
}


missclassification_rate_df

gene_run%>%
  dplyr::mutate(counter=1)%>%
  dplyr::group_by(genes)%>%
  dplyr::summarise(counter=sum(counter))%>%View()




