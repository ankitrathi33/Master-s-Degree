library(Biobase)
library(devtools)
library(GSE5859)
library(GSE5859Subset)
library(RColorBrewer)
library(PCAtools)
library(qvalue)
library(genefilter)
library(dplyr)

data(GSE5859)

geneExpression <- exprs(e)
sampleInfo <- pData(e)

cors <- cor(geneExpression)
#Q1
# create an array of index pairs of samples with correlation coefficient equal to 1
Pairs <- which(abs(cors)==1,arr.ind=TRUE)
# extract pairs of samples where the two indexes differ
out <- Pairs[which(Pairs[,1]!=Pairs[,2]),,drop=FALSE]

e <- e[,-out[2]]
out <- grep("AFFX",featureNames(e))
e <- e[-out,]

#filtering gene expression levels
geneExpression <- exprs(e)
sampleInfo <- pData(e)

# Batch effect identification
#taking out year from each date
sampleInfo$year = format(sampleInfo$date,"%y")

#ethnicity and year table
sampleInfo%>%dplyr::group_by(year,ethnicity)%>%
  dplyr::summarise(count=n())%>%tidyr::spread(ethnicity ,count,fill=0)%>%View()

table(sampleInfo$ethnicity,sampleInfo$year)
#Q2
# create mean centered gene expression matrix
y <- geneExpression-rowMeans(geneExpression)
# load color palette
library(RColorBrewer)
cols=colorRampPalette(rev(brewer.pal(11,"RdBu")))(100)
# plot correlation matrix of the entire data set
image(cor(y),col=cols,zlim=c(-1,1))

#Q3

library(PCAtools)
rownames(sampleInfo) <- sampleInfo$filename
pc <- pca(geneExpression, metadata = sampleInfo)
screeplot(pc, components = 1:30)

biplot(pc, colby="ethnicity",
       legendPosition = "right",
       lab='')


biplot(pc, colby="year",
       legendPosition = "right",
       lab='')

library(qvalue)
library(genefilter)
# extract gene expression data for CEU measured in 2002 and 2003
sub1 <- t(subset(t(geneExpression), sampleInfo$ethnicity=="CEU" &
                   sampleInfo$year=="02" | sampleInfo$year=="03"))
# extract relevant sample information
sub1Info <- subset(sampleInfo, sampleInfo$ethnicity=="CEU" &
                     sampleInfo$year=="02" | sampleInfo$year=="03")
# perform t-tests for each row
tt <- rowttests(sub1,factor(sub1Info$year))
# calculate multiple testing correction q-values
qsub1 <- qvalue(tt$p.value)$qvalues

#q values less than 0.05
sum(qsub1<0.05) #4278


#Q6 comparing 2003 and 2004

# extract gene expression data for CEU measured in 2003 and 2004
sub2 <- t(subset(t(geneExpression), sampleInfo$ethnicity=="CEU" &
                   sampleInfo$year=="03" | sampleInfo$year=="04"))
# extract relevant sample information
sub2Info <- subset(sampleInfo, sampleInfo$ethnicity=="CEU" &
                     sampleInfo$year=="03" | sampleInfo$year=="04")
# perform t-tests for each row
tt2 <- rowttests(sub2,factor(sub2Info$year))
# calculate multiple testing correction q-values
qsub2 <- qvalue(tt2$p.value)$qvalues

#q values less than 0.05
sum(qsub2<0.05) #2448


#Q7 comparing ASN and CEU

# extract gene expression data for  ASN and CEU
sub_eth <- t(subset(t(geneExpression),sampleInfo$ethnicity=="ASN" | sampleInfo$ethnicity=="CEU"))
# extract relevant sample information
sub_eth_info <- subset(sampleInfo, sampleInfo$ethnicity=="ASN"| sampleInfo$ethnicity=="CEU")
# perform t-tests for each row
tt3 <- rowttests(sub_eth,factor(sub_eth_info$ethnicity))
# calculate multiple testing correction q-values
qsub3 <- qvalue(tt3$p.value)$qvalues

#q values less than 0.05
sum(qsub3<0.05) #7175

#Q8 comparing ASN and CEU in 2005
# Comparing ASN and CEU in 2005

sub_eth05 <- t(subset(t(geneExpression), (sampleInfo$year=="05") &
                   (sampleInfo$ethnicity=="ASN" | sampleInfo$ethnicity=="CEU")))
# extract relevant sample information
sub_eth_info05 <- subset(sampleInfo, (sampleInfo$year=="05" )&
                     (sampleInfo$ethnicity=="ASN" | sampleInfo$ethnicity=="CEU"))
# perform t-tests for each row
tt4 <- rowttests(sub_eth05,factor(sub_eth_info05$ethnicity))
# calculate multiple testing correction q-values
qsub4 <- qvalue(tt4$p.value)$qvalues

#q values less than 0.05
sum(qsub4<0.05) #561

# Batch effect adjustment

library(GSE5859Subset)
data(GSE5859Subset)
sex = sampleInfo$group

# extract month from sample processing date
month = factor(format(sampleInfo$date,"%m"))
# display level of confounding
table(sampleInfo$group, month)
tt <- rowttests(geneExpression,factor(sampleInfo$group))
qgr <- qvalue(tt$p.value)
ind <- which(qgr$qvalues<0.1)
length(ind)
table(geneAnnotation$CHR[ind])/sum(table(geneAnnotation$CHR[ind]))
table(geneAnnotation$CHR[ind])
0.13559322 +0.20338983


ind <- which(geneAnnotation$CHR[ind]!="chrX"
             & geneAnnotation$CHR[ind]!="chrY")
tt <- rowttests(geneExpression[ind,],factor(month))
length(which(tt$p.value<0.05))/length(tt$p.value)


p <- c()
for (i in 1:dim(geneAnnotation)[1]){
  # model matrix accounting for month and sex
  X = model.matrix(~sex+month)
  # extract single gene expression vector
  y = geneExpression[i,]
  # fit linear model
  fit = lm(y~X)
  # extract p-value for sex group comparison
  p[i] <- summary(fit)$coef[2,4]
}
# calculate q-values
qgr <- qvalue(p)
ind <- which(qgr$qvalues<0.1)
table(geneAnnotation$CHR[ind])/sum(table(geneAnnotation$CHR[ind]))
table(geneAnnotation$CHR[ind])

length(ind)

ind <- which(geneAnnotation$CHR[ind]!="chrX"
             & geneAnnotation$CHR[ind]!="chrY")
tt <- rowttests(geneExpression[ind,],factor(month))
length(which(tt$p.value<0.05))/length(tt$p.value)
