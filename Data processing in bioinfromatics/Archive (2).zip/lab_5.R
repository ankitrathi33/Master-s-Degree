if (!requireNamespace("Seurat", quietly = TRUE))
  install.packages("Seurat")
install.packages('npsurv')
norequire('Seurat')
library(Seurat)
library(ggplot2)
library(dplyr)
setwd(paste(getwd(),'/Documents/Golu Projects/lab_5',sep=''))

load('scRNAseq.RData')

table(labs$celltype)%>%View()


melanoma <- CreateSeuratObject(counts = counts,
                               project = "melanoma")
melanoma[["tumor"]] <- labs$tumor

# Now add two other variables to your Seurat object: malignant and
#celltype.

melanoma[["malignant"]] <- labs$malignant
melanoma[["celltype"]] <- labs$celltype


melanoma <- NormalizeData(melanoma)


melanoma<-FindVariableFeatures(melanoma,selection.method = "vst",nfeatures=1000) 

VariableFeaturePlot(melanoma)


all.genes <- rownames(melanoma)
melanoma <- ScaleData(melanoma, features = all.genes)

melanoma <- RunPCA(melanoma,
                   features = VariableFeatures(object = melanoma))

DimPlot(melanoma, reduction = "pca")


ElbowPlot(melanoma)

x<-5
melanoma <- FindNeighbors(melanoma, dims = 1:x)
melanoma <- FindClusters(melanoma, resolution = 0.5)
melanoma <- RunUMAP(melanoma, dims = 1:x)




DimPlot(melanoma, reduction = "umap", label = TRUE)
#9. Create five character vectors, one for each cell type, containing the
#names of gene biomarkers.

# T-cells: CD2, CD3D, CD3E, CD3G
# B-cells: CD19, CD79A, CD79B, BLK
# Macrophages: CD163, CD14, CSF1R
# Endothelial cells: PECAM1, VWF, CDH5
# CAF: FAP, THY1, DCN, COL1A1, COL1A2, COL6A1, COL6A2, COL6A3
Tcellbiomarkers=c('CD2','CD3D','CD3E','CD3G')
Bcellbiomarkers=c('CD19','CD79A','CD79B','BLK')
Macrophages<-c('CD163','CD14','CSF1R')
Endothelial<-c('PECAM1','VWF','CDH5')
CAF<-c("FAP", "THY1", "DCN", "COL1A1", "COL1A2", "COL6A1", "COL6A2", "COL6A3")


VlnPlot(melanoma, features = Tcellbiomarkers, pt.size = 0)


FeaturePlot(melanoma, features = Tcellbiomarkers)
FeaturePlot(melanoma, features = Bcellbiomarkers)
FeaturePlot(melanoma, features = Macrophages)
FeaturePlot(melanoma, features = Endothelial)
FeaturePlot(melanoma, features = CAF)



DimPlot(melanoma, reduction = "umap", label = TRUE,group.by = 'celltype')


DimPlot(melanoma, reduction = "pca",group.by = 'celltype')





