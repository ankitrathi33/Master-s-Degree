if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("KEGGREST")

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("biomaRt")

install.packages('tmod')

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("pathview")


library(KEGGREST)
library(tmod)
library(biomaRt)
library(pathview)
library(ggplot2)
library(dplyr)
setwd(paste(getwd(),'/Documents/Golu Projects/lab_4',sep=''))

load('Gene_data_Lab4.RData')

gene_data$significant = as.vector(ifelse(gene_data$p_value <= 0.05,TRUE,FALSE))

gene_data$significant%>%table()
load('paths_KEGG.RData')



mouse_mart = useMart("ensembl", dataset = "mmusculus_gene_ensembl")
genes_entrez = getLDS(attributes = c("mgi_symbol"),
                      filters = "mgi_symbol",
                      values = gene_data$Genes ,
                      mart = mouse_mart,
                      attributesL = c("entrezgene_id"),
                      martL = mouse_mart,
                      uniqueRows=T)

gene_data_results <- merge(gene_data, genes_entrez, by.x = 'Genes', by.y = 'MGI.symbol')
gene_data_results <- na.omit(gene_data_results)

nrow(gene_data_results)

fg = gene_data_results$NCBI.gene.ID[gene_data_results$significant == 1]
bg = gene_data_results$NCBI.gene.ID


HGtest_results<-tmodHGtest(fg=fg, bg=bg, mset=KEGGmm, qval=1.1, order.by='none')

table(HGtest_results$P.Value<0.05)
table(HGtest_results$adj.P.Val<0.05)

HGtest_results[HGtest_results$P.Value==min(HGtest_results$P.Value),]

#Q7.
HGtest_results$alpha=HGtest_results$b
HGtest_results$gamma=HGtest_results$B
HGtest_results$beta=HGtest_results$n-HGtest_results$alpha
HGtest_results$delta=HGtest_results$n-HGtest_results$alpha
HGtest_results$OddsRatio=(HGtest_results$alpha*HGtest_results$delta)/(HGtest_results$beta*HGtest_results$gamma)

#Q8.

HGtest_results$log_p=log(HGtest_results$P.Value)

ggplot(HGtest_results,aes(x=log_p,y=OddsRatio))+geom_point()


#FCS
input_to_cerno <- gene_data_results$NCBI.gene.ID[order(abs(gene_data_results$Statistic), decreasing = TRUE)]

CERNOtest_results<-tmodCERNOtest(input_to_cerno, mset=KEGGmm, qval=1.1, order.by='none')

table(CERNOtest_results$P.Value<0.05)
table(CERNOtest_results$adj.P.Val<0.05)

CERNOtest_results[CERNOtest_results$P.Value==min(CERNOtest_results$P.Value),]



#common pathway


ora_paths<-HGtest_results[HGtest_results$P.Value<0.05,'ID']
fcs_paths<-CERNOtest_results[CERNOtest_results$P.Value<0.05,'ID']
common_paths<-intersect(ora_paths,fcs_paths)
common_paths

#best path
best_pathway_ID=CERNOtest_results[CERNOtest_results$P.Value==min(CERNOtest_results$P.Value),'ID']
best_pathway_ID==HGtest_results[HGtest_results$P.Value==min(HGtest_results$P.Value),"ID"]

library(pathview)

gene.data = gene_data_results$Statistic
names(gene.data) <- gene_data_results$NCBI.gene.ID
pv.out <- pathview(gene.data = gene.data,
                   gene.idtype = "KEGG",
                   pathway.id = best_pathway_ID,
                   species = "mmu",
                   kegg.native = T,
                   limit = list(gene=2))






